import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Salary {
    public static void main(String[] args) {

        MyFrame myFrame = new MyFrame();

    }
}